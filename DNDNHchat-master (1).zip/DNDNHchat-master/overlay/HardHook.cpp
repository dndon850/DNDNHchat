// Copyright The Mumble Developers. All rights reserved.
// Use of this source code is governed by a BSD-style license
// that can be found in the LICENSE file at the root of the
// Mumble source tree or at <https://www.mumble.info/LICENSE>.

#ifdef USE_MINHOOK
#	include "HardHook_minhook.cpp"
#else
#	include "HardHook_x86.cpp"
#endif
